package com.prototipo.brian;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BrianApplication {

	public static void main(String[] args) {
		SpringApplication.run(BrianApplication.class, args);
	}

}
