package com.prototipo.brian;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BrianApplicationTests {

	@Test
	void contextLoads() {
	}

}
